import { Link } from "react-router-dom"

function Joao() {
    return (
        <div>
            <h1>Página do João</h1>
            <Link to={'/'}>Voltar para Home</Link>
        </div>
    )
}

export default Joao